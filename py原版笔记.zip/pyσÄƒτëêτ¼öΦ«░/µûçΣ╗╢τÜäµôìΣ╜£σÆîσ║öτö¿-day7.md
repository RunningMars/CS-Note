# 1、文件的介绍

> 文件：就是以硬盘为载体，存储计算机所产生的数据

学习文件的目的：把程序中所产生的数据保存到文件，能够让数据永久存储

永久存储的方式：

1. 文件
2. 数据库，读写性能非常快，效率更高

# 2、文件的读取

> 文件的读取方式为：
>
> - `r` 模式：以字符串的方式读取文件中的数据
> - `rb` 模式：以二进制(字节)的方式读取文件中的数据

### r 模式



```bash
# 第一步：打开文件
file = open("test.txt", "r", encoding="utf-8")
# 查看打开文件使用的编码格式
# cp936 => gbk
print(file.encoding)
# 第二步：读取文件中的数据
result = file.read() # 读取文件中的所有数据
print(result, type(result))
# 第三步: 关闭文件
file.close()
```

运行结果：



```kotlin
utf-8
人生苦短，我用python!
人生苦短，我用python!
人生苦短，我用python!
 <class 'str'>
```

#### r模式的注意点

- 1. 要打开的文件必须存在，否则就崩溃
- 1. 打开文件默认是在当前工程目录下面，如果打开的文件没有在当前工程里面，需要加上文件的路径
- 1. 在`window`的`python`解释器下面，打开文件默认使用的是`gbk`编码，`mac`或者`Linux`的`python`解释器，打开文件默认是`utf-8`

### rb 模式 — 以二进制(字节)的方式读取文件中的数据

> 比如：视频，图片，音频等数据需要使用`rb`模式读取文件中的数据

打开一张图片：



```bash
# # 第一步：打开文件
file = open("11.png", "rb")
# # 第二步：读取文件中的数据
result = file.read()
print(result, type(result))
# # 第三步：关闭文件
file.close()
```

运行结果是一行特别长的二进制代码，我简化一下展示：



```kotlin
b'\xe4\xba\xba\xa8python!\r\n' <class 'bytes'>
```

注意：数据前带`b` 表示字节数据或者二进制数据

**`rb` 模式读取文本文件中的数据：**



```bash
# 第一步：打开文件
file = open("test.txt", "rb")
# 第二步：读取文件中的数据
result = file.read()
print(result, type(result))

# 需要对二进制数据进行解码，转成字符串数据
content = result.decode("utf-8")
print(content, type(content))
# 第三步：关闭文件
file.close()
```

运行结果：



```kotlin
b'\xe4\xba\xba\xe7\x94\x9f\xa8python!\r\n' <class 'bytes'>
人生苦短，我用python!
人生苦短，我用python!
人生苦短，我用python!
 <class 'str'>
```

![img](https:////upload-images.jianshu.io/upload_images/15992481-c83b09bd82b43880.png?imageMogr2/auto-orient/strip|imageView2/2/w/675/format/webp)

# 3、文件的写入

> 向文件写入数据的操作为:

- 1. `w`模式： 以字符串的方式写入数据
- 1. `wb`模式： 以二进制(字节)的方式写入数据

### w模式



```bash
# 第一步：打开文件
file = open("2.txt", "w", encoding="utf-8")
# 查看打开文件，操作文件的编码格式
print(file.encoding)

# 第二步: 向文件中写入数据(字符串)
file.write("hello\n")
file.write("world\n")
file.write("哈哈")

# 第三步: 关闭文件
file.close()
```

#### w模式的注意点：

- 1. 当打开的文件不存在时，默认会创建一个指定的文件
- 1. 当打开的文件存在时，先把原文件中的所有数据清空，然后再写入指定的数据

### wb模式 — 以二进制(字节)的方式写入数据



```bash
# 第一步：打开文件
file = open("2.txt", "wb")

# 第二步: 向文件中写入数据(字符串)
content = "哈哈"
# 把字符串编码成二进制(字节)也就是把字符串转成二进制
content_data = content.encode("utf-8")
file.write(content_data)

# 第三步: 关闭文件
file.close()
```

# 4、文件的追加写入

- a模式： 以字符串的方式追加写入数据
- ab模式： 以二进制(字节)的方式追加写入数据

### a模式 — 以字符串的方式追加写入数据



```bash
# 第一步：打开文件
file = open("3.txt", "a", encoding="utf-8")

# 第二步: 追加写入数据(字符串数据)
file.write("嘻嘻")

# 第三步: 关闭文件
file.close()
```

#### a模式的注意点：

- 当打开的文件不存在时，那么默认会创建一个指定的文件
- 当打开的文件存在时，原文件中的数据会进行保留，在原文件数据的末尾追加写入指定的数据

### ab模式 - 以二进制(字节)的方式追加写入数据



```bash
# 第一步：打开文件
file = open("3.txt", "ab")

# 第二步: 追加写入数据(二进制数据)
content = "哈哈"
# 对字符串进行编码，把字符串转成二进制数据(字节数据)
data = content.encode("utf-8")
print(type(data))
file.write(data)

# 第三步: 关闭文件
file.close()
```

# 5、文件读取数据的其他常用方法

- read方法，需要指定参数
- readline方法：读取一行数据
- readlines方法：读取所有行数据

### read方法带有参数的使用

> read(数据长度)：如果文件的操作模式是r模式，这里的数据长度是字符串的数据长度



```bash
file = open("test.txt", "r", encoding="utf-8")

#6：表示读取6个字符串数据的长度
result = file.read(6)
print(result)

file.close()
```

运行结果：



```undefined
人生苦短，我
```

> read(数据长度)：如果文件的操作模式是rb模式，这里的数据长度是字节的数据长度。

提示：在utf-8编码格式下，一个汉字占用三个字节，一个字母，数字占用1个字节



```bash
file = open("test.txt", "rb")

### 3：表示读取3个字节数据的长度
# 提示：在utf-8编码格式下，一个汉字占用三个字节，一个字母，数字占用1个字节
result = file.read(3)
print(result)
# 对二进制数据进行解码转成字符串
content = result.decode("utf-8")
print(content)

result = file.read(3)
print(result)
# 对二进制数据进行解码转成字符串
content = result.decode("utf-8")
print(content)

file.close()
```

运行结果：



```bash
b'\xe4\xba\xba'
人
b'\xe7\x94\x9f'
生
```

### readlines方法：读取所有行数据



```bash
file = open("test.txt", "r", encoding="utf-8")

# 读取文件中的所有行数据
result = file.readlines()
print(result, type(result))

for row in result:
    print(row)

file.close()
```

运行结果：



```kotlin
['人生苦短，我用python!\n', '人生苦短，我用python!\n', '人生苦短，我用python!\n'] <class 'list'>
人生苦短，我用python!

人生苦短，我用python!

人生苦短，我用python!
```

### readline方法：读取一行数据



```bash
file = open("test.txt", "r", encoding="utf-8")

# 读取文件中的一行数据
result = file.readline()
print(result, type(result))

for row in result:
    print(row)

file.close()
```

运行结果：



```kotlin
人生苦短，我用python!
 <class 'str'>
人
生
苦
短
，
我
用
p
y
t
h
o
n
!
```

## with语句的使用

文件使用完后必须关闭，因为文件对象会占用操作系统的资源，并且操作系统同一时间能打开的文件数量也是有限的，文件在读写时都有可能产生`IOError`，一旦出错，后面的`f.close()`就不会调用。**Python提供了 with 语句的这种写法，既简单又安全，并且 with 语句执行完成以后自动调用关闭文件操作，即使出现异常也会自动调用关闭文件操作。**

#### with 语句的示例代码：



```python
# 1.以写的方式打开文件
with open("1.txt", "w") as f:
    # 2.读取文件内容
    f.write("hello world")
```

# 6、文件的拷贝

我们想把原文件`test.txt`拷贝一份为`test[复件].txt`：



```bash
# 原文件的名字
src_file_name = "test.txt"

# 根据点把原文件的名字分割成三部分
file_name, point, end_str = src_file_name.partition(".")

# 生成目标文件的名字  test[复件].txt
dst_file_name = file_name + "[复件]" + point + end_str
print(dst_file_name)

# 1. 打开目标文件(拷贝后的文件 test[复件].txt)
dst_file = open(dst_file_name, "wb")

# 2. 打开原文件，读取原文件中的数据
src_file = open(src_file_name, "rb")

# 读取原文件中的所有二进制数据
src_file_data = src_file.read()

# 3. 把读取到的原文件数据写入到目标文件(拷贝后的文件 test[复件].txt)
dst_file.write(src_file_data)

# 4. 把文件关闭
src_file.close()
dst_file.close()
```

### 大文件拷贝



```php
# 原文件的名字
src_file_name = "test.txt"

# 根据点把原文件的名字分割成三部分
file_name, point, end_str = src_file_name.partition(".")

# 生成目标文件的名字  test[复件].txt
dst_file_name = file_name + "[复件]" + point + end_str
print(dst_file_name)

# 1. 打开目标文件(拷贝后的文件 test[复件].txt)
dst_file = open(dst_file_name, "wb")

# 2. 打开原文件，读取原文件中的数据
src_file = open(src_file_name, "rb")

while True:
    # 读取原文件中的所有二进制数据
    src_file_data = src_file.read(1024) # 每次读取最大字节数是1024
    # if len(src_file_data) > 0:
    # if 判断的简写
    if src_file_data:
        # 3. 把读取到的原文件数据写入到目标文件(拷贝后的文件 test[复件].txt)
        dst_file.write(src_file_data)
    else:
        print("文件拷贝完毕")
        # 提示：如果读取到数据长度是0表示文件读取完成
        break
# 4. 把文件关闭
src_file.close()
dst_file.close()
```

## if 判断的扩展

- if语句结合 bool 类型
- if语句结合容器类型
- if语句结合非零即真
- if语句结合 None

#### if语句结合 bool 类型



```php
if False:
    print("ok")
else:
    print("error")
```

运行结果：



```undefined
error
```

#### if语句结合容器类型

> 说明：如果 `if` 语句结合容器类型使用，容器类型里面有数据表示条件成立，否则容器类型里面没有数据表示条件失败

容器类型：字符串，列表，元组，字典，集合，range, 二进制
 **if语句结合字符串：**



```bash
my_value = "b"
if my_value:
    print("ok")
else:
    print("error")

################ 运行结果 ################

ok
```

**if语句结合range：**



```bash
my_range = range(0)

if my_range:
    print("ok")
else:
    print("error")

################ 运行结果 ################

error
```

**if语句结合集合：**



```bash
my_set = set()
if my_set:
    print("ok")
else:
    print("error")

################ 运行结果 ################

error
```

**if语句结合列表：**



```bash
my_list = [1,3,5]
if my_list:
    print("ok")
else:
    print("error")

################ 运行结果 ################

ok
```

# 7、文件和文件夹的相关操作

**操作文件和文件夹的模块：**



```swift
import os
```

**文件和文件夹操作的高级模块：**



```swift
import shutil
```

### 创建空的文件



```go
file = open("abcd.txt", "wb")
file.close()
```

### 重命名



```css
import os

###将abcd.txt文件重命名为aaa.txt
os.rename("abcd.txt", "aaa.txt")
```

### 删除文件



```swift
import os
os.remove("1.txt")
```

#### 创建文件夹



```swift
import os
os.mkdir("AAA")
```

#### 查看当前操作目录的路径



```swift
import os
path = os.getcwd()

print(path)
```

#### 切换目录



```swift
import os
os.chdir("AAA")

path = os.getcwd()
print(path)
```

#### 切换到上一级路径



```swift
import os
os.chdir("..")
path = os.getcwd()

print(path)
```

#### 删除文件



```swift
import os
os.remove("AAA/abcd.txt")
```

#### 删除非空文件夹



```swift
import os
os.rmdir("CCC")
```

#### 删除空目录



```swift
import os
os.rmdir("BBB")
```

#### 删除非空目录



```swift
import shutil
shutil.rmtree("CCC")
```

#### 查看目录下的所有文件名



```python
import os

# 默认查看当前目录下的所有文件名
result = os.listdir()  #等价于 result = os.listdir(".")
print(result)
```

#### 查看指定目录下的所有文件名



```swift
import os

result = os.listdir("CCC")
print(result)
```

#### 判断指定文件是否存在



```swift
import os
result = os.path.exists("4.txt")
print(result)
```

#### 判断指定文件夹是否存在



```swift
import os
result = os.path.exists("AA")
print(result)
```

#### 获取指定文件的文件名和文件的后缀



```swift
import os
file_name, end_str = os.path.splitext("3.txt")
print(file_name, end_str)
```

#### 判断是否是文件



```swift
import os
result = os.path.isfile("DD")
print(result)
```

#### 判断是否是文件夹



```swift
import os
result = os.path.isdir("3.txt")
print(result)
```

# 批量修改文件名

> 我们把`test`目录下的所有文件名前面都加上一个`[黑马出品]-`：



```python
import os

# 1. 获取指定目录下的所有文件名
file_name_list = os.listdir("test")
print(file_name_list)

# 切换到test目录里面
path = os.getcwd()
print(path)

os.chdir("test")

path = os.getcwd()
print(path)

# 2. 遍历文件名列表获取每一个文件名，然后依次对文件进行重命名
for file_name in file_name_list:
    # 生成重命名后的文件名
    rename_file_name = "[黑马出品]-" + file_name
    print(file_name, rename_file_name)
    # 使用rename函数进行重命名
    os.rename(file_name, rename_file_name)
```

#### 学生管理系统文件版



```python
# 学生管理系统的分析：
# 1. 每个学生的信息使用字典进行存储
# 2. 对于学生管理系统，是需要管理不同学生的，所以学生管理系统里面需要在定义列表，使用列表管理不同的学生字典信息
import os

# 定义全局变量的学生列表
student_list = []


# 显示学生管理系统的功能菜单
def show_menu():
    print("--------------学生管理系统V1.0------------")
    print("1. 添加学生")
    print("2. 修改学生")
    print("3. 删除学生")
    print("4. 查询学生")
    print("5. 显示所有学生")
    print("6. 退出")


# 添加学生
def add_student():
    name = input("请输入学生的姓名:")
    age = input("请输入学生的年龄:")
    sex = input("请输入学生的性别:")

    # 使用字典存储每个学生的信息
    student_dict = {}
    # 添加键值对
    student_dict["name"] = name
    student_dict["age"] = age
    student_dict["sex"] = sex

    # 把学生字典添加到学生列表里面
    student_list.append(student_dict)
    print("添加成功")


# 显示所有学生的信息
def show_all_students():
    # 遍历学生列表，显示每一个学生信息
    for index, student_dict in enumerate(student_list):
        # 学号 = 下标 + 1
        student_no = index + 1
        print("学号: %d 姓名: %s 年龄: %s 性别: %s" % (student_no,
                                               student_dict["name"],
                                               student_dict["age"],
                                               student_dict["sex"]))


# 修改学生信息
def modify_student():
    # 接收用户输入学生的学号
    student_no = int(input("请输入您要修改学生的学号:"))

    # 计算学生列表的下标 = 学号 - 1
    index = student_no - 1

    # 判断下标的范围是否是一个合法的范围
    if index >= 0 and index < len(student_list):

        # 根据下标获取对应的学生字典信息
        student_dict = student_list[index]

        # 重新接收用户输入的学生信息
        new_name = input("请输入修改后学生的姓名:")
        new_age = input("请输入修改后学生的年龄:")
        new_sex = input("请输入修改后学生的性别:")

        # 修改字典信息
        student_dict["name"] = new_name
        student_dict["age"] = new_age
        student_dict["sex"] = new_sex

        print("修改成功")
    else:
        print("请输入合法的学号！")


# 删除学生信息
def remove_student():
    # 接收用户输入学号
    student_no = int(input("请输入要删除学生的学号:"))
    # 根据学号计算学生的下标
    index = student_no - 1

    # 判断下标的范围是否是一个合法的范围
    if index >= 0 and index < len(student_list):
        # 根据下标删除对应的学生信息
        del student_list[index]
        print("删除成功")
    else:
        print("请输入合法的学号！")


# 查询学生
def query_student():
    # 接收用户输入的学生姓名
    name = input("请输入要查询学生的姓名:")
    # 遍历列表获取每一个学生字典信息
    for index, student_dict in enumerate(student_list):
        if student_dict["name"] == name:
            # 生成学生的学号
            student_no = index + 1
            # 代码执行到此，说明找到了学生信息
            print("学号: %d 姓名: %s 年龄: %s 性别: %s" % (student_no,
                                                   student_dict["name"],
                                                   student_dict["age"],
                                                   student_dict["sex"]))
            break
    else:
        print("对不起，您查找的学生信息不存在!")


# 保存列表数据到文件
def save_data():
    # 1. 打开文件
    file = open("student_list.data", "w", encoding="utf-8")
    # 2. 把列表数据转成字符串保存到文件
    student_list_str = str(student_list)
    print(student_list_str, type(student_list_str))
    file.write(student_list_str)
    # 3. 关闭文件
    file.close()


# 加载缓存文件中的数据
def load_data():
    # 1. 判断缓存文件是否存在
    if os.path.exists("student_list.data"):
        # 2. 如果缓存文件存在，读取文件中的数据
        file = open("student_list.data", "r", encoding="utf-8")
        file_data = file.read()
        # 3. 把读取到数据给全局变量(student_list)
        # "[{'name': '李四', 'age': '20', 'sex': '男'}, {'name': '王五', 'age': '20', 'sex': '男'}]"
        # 如果字符串列表转成列表
        new_student_list = eval(file_data)

        # 把读取到列表中的每一个数据添加到全局变量列表里面
        student_list.extend(new_student_list)


# 程序的入口函数，程序第一个要执行的函数
def start():
    # 程序启动后，加载文件中的数据只加载一次即可
    load_data()
    while True:
        # 显示学生管理系统的功能菜单
        show_menu()

        # 接收用户输入的功能选项
        menu_option = input("请输入您需要的功能选项:")

        # 判断功能选项
        if menu_option == "1":
            print("添加学生")
            add_student()
        elif menu_option == "2":
            print("修改学生")
            modify_student()
        elif menu_option == "3":
            print("删除学生")
            remove_student()
        elif menu_option == "4":
            print("查询学生")
            query_student()
        elif menu_option == "5":
            print("显示所有学生")
            show_all_students()
        elif menu_option == "6":
            print("退出")
            # 把列表数据保存到文件，可以做到永久存储
            save_data()
            break

# 启动学生管理系统
start()

# 快捷键：ctr + - 把函数的代码折叠起来， ctr + + 把函数的代码展开
# 快捷键：ctr + shift + - 把所有函数的代码折叠起来， ctr + shift + + 把所有函数的代码展开
```



作者：黄晶_id
链接：https://www.jianshu.com/p/b784035aa6af
来源：简书
著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。