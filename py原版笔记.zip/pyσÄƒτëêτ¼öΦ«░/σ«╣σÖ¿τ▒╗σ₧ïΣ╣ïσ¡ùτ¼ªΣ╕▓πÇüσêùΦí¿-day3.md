# 字符串

#### 字符串定义方式有四种：

**单引号字符串：**

```python
my_str1 = 'hello'
```

**双引号字符串：**



```python
my_str2 = "你好"
```

**三个单引号字符串：**



```python
### 三个单引号/双引号之间可以定义多行字符串
my_str3 = '''
哈哈
嘻嘻  
嘿嘿'''
```

**三个双引号字符串：**



```python
### 三个单引号/双引号之间可以定义多行字符串
my_str4 = """A
B
C"""
```

我们看`print`之后的效果：



```python
print(my_str1, type(my_str1))
print(my_str2, type(my_str2))
print(my_str3, type(my_str3))
print(my_str4, type(my_str4))

#########  输出为  ############

hello <class 'str'>
你好 <class 'str'>

哈哈
嘻嘻
嘿嘿 <class 'str'>
A
B
C <class 'str'>
```

**总结： 如果字符串内容有多行那么我们使用三引号字符串，如果字符串内容只用一行那么可以使用单引号或者双引号字符串**

## 1. 字符串输入和输出

之前在学习`input`的时候，通过它能够完成从键盘获取数据，然后保存到指定的变量中：



```python
name = input("请输入您的姓名:")
age = int(input("请输入您的年龄:"))
address = input("请输入您的地址:")

print("我叫:%s 年龄: %d 地址: %s" % (name, age, address))

#########  输出为  ############

请输入您的姓名:小明
请输入您的年龄:26
请输入您的地址:北京
我叫:小明 年龄: 26 地址: 北京
```

**注意：`input`获取的数据，都以字符串的方式进行保存，即使输入的是数字，那么也是以字符串方式保存。**我们这里`print`里年龄后面的占位符是整数型`%d`，所以需要通过**`int(input("请输入您的年龄:"))`操作将字符型转成整数型**。如果我们年龄的输出也用`%s`占位，那就不需要转型操作。

## 2. f-string 的使用

> f-string是python3.6及以上版本提供动态绑定字符串数据的一个新特性 —— 相当于字符串动态绑定数据格式化占位符的简化版本。

用法一：



```python
name = input("请输入您的姓名:")
age = int(input("请输入您的年龄:"))
# f-string:动态绑定数据只需要一对大括号即可
my_str = f"我叫:{name} 年龄:{age}"
print(my_str, type(my_str))

#########  输出为  ############

请输入您的姓名:小明
请输入您的年龄:26
我叫:小明 年龄:26 <class 'str'>
```

用法二：



```python
num1 = int(input("请输入第一个数字:"))
num2 = int(input("请输入第二个数字:"))

message = F'{num1} + {num2} = {num1 + num2}'
print(message)

#########  输出为  ############

请输入第一个数字:10
请输入第二个数字:90
10 + 90 = 100
```

*提示：字符串动态绑定数据格式化占位符方式最通用， 不涉及版本问题*

## 3. 下标和切片

### 下标-索引

> - 下标：又称为索引，其实就是数字，下标在python里面可以分为正数下标和负数下标。
> - 下标：根据下标可以获取和删除指定位置的数据，下标是用来标识不同数据，通俗理解下标是用来区分不同数据的。

如果有字符串 : `name = 'abcdef'`，在内存中的实际存储如下 :

![img]()


 如果想取出部分字符，那么可以通过下标的方法，（注意python中下标从 0 开始）





```python
name = 'abcdef'

   print(name[0])
   print(name[1])
   print(name[2])

#########  输出为  ############
a
b
c
```

### 切片

> **切片：根据下标范围获取对象(字符串，列表，元组)中的一部分数据。**

#### 切片的语法格式：

**my_str[开始下标: 结束下标: 步长] 注意点：结束下标不包含，步长不指定默认是1。**

#### 切片获取字符串中一部分数据：



```python
my_str = "abcedf"
result = my_str[0:3]
print(result)

#########  输出为  ############
abc
```

#### 获取前三个字符串的简写：



```python
my_str = "abcedf"
result = my_str[:3]
print(result)

#########  输出为  ############
abc
```

#### 根据指定下标获取到最后一个数据简写方式：



```python
my_str = "abcedf"
result = my_str[3:]
print(result)

#########  输出为  ############
edf
```

#### 获取倒数后面三个字符串数据的简写方式 ：



```python
my_str = "abcedf"
result = my_str[-3:]
print(result)

#########  输出为  ############
edf
```

#### 获取字符串中的整个数据 :



```python
my_str = "abcedf"
result = my_str[:]
print(result)
result = my_str[::1]
print(result)

#########  输出为  ############
abcedf
abcedf
```

#### 指定步长：



```python
my_str = "abcedf"
result = my_str[::2]
print(result)

result = my_str[-2:-6:-1]
print(result)

#########  输出为  ############
acd
decb
```

*注意点：切片的范围如果有问题，获取数据是不会报错，但是获取的数据是一个空的字符串数据*

> **总结：如果步长是正数表示从左到右取值，如果步长是负数表示从右到左取值。**
>
> - **下标-索引是通过下标取某一个元素**
> - **切片是通过下标去某一段元素**

------

> **（面试题）给定一个字符串aStr, 请反转字符串**

#### python 字符串快速逆置：



```python
aStr = "hello"
print(aStr[::-1])  # 从后向前，按步长为1进行取值

#########  输出为  ############
olleh
```

扩展总结：



```python
s = 'Hello World!'

print(s[4])

print(s)

print(s[:]) # 取出所有元素（没有起始位和结束位之分），默认步长为1

print(s[1:]) # 从下标为1开始，取出 后面所有的元素（没有结束位）

print(s[:5])  # 从起始位置开始，取到 下标为5的前一个元素（不包括结束位本身）

print(s[:-1]) # 从起始位置开始，取到 倒数第一个元素（不包括结束位本身）

print(s[-4:-1]) # 从倒数第4个元素开始，取到 倒数第1个元素（不包括结束位本身）

print(s[1:5:2]) # 从下标为1开始，取到下标为5的前一个元素，步长为2（不包括结束位本身）

#########  输出为  ############
o
Hello World!
Hello World!
ello World!
Hello
Hello World
rld
el
```

## 4. 字符串常见操作

### (1) find

> **find: 根据指定字符串，获取字符串所在的下标**

注意：如果没有找到对应的字符串，返回 -1，这里 -1 不是最后一个元素表示的是没有找到字符串的下标位置。

比如，我们有一个字符串：`my_str = "hello"`，我们想知道 `e` 这个字符串是否在`my_str`中前两个位置，如果在就返回`e` 所在的下标，不在返回 -1：



```python
my_str = "hello"
result = my_str.find("e", 0, 2)
print(result)

############## 运行结果 ###############

1
```

`my_str.find("查找的指定字符串", 开始下标, 结束下标[不包含])`
 `my_str.find("e", 0, 2)`：查找`e`是否在`hello`中的前两个字符中，如果在就返回所对应的下标。

再比如，有字符串`my_str = 'you are more than what you have become '`，检测字符串 `more` 是否包含在`my_str`中，如果包含则返回`more`中第一字母的索引值（所对应的下标），否则返回-1：



```python
my_str = 'you are more than what you have become '
result = my_str.find("more", 0, len(my_str))
print(result)

############## 运行结果 ###############

8
my_str.find("more", 0, len(my_str))` 查找字符串 `more` 是否在 `'you are more than what you have become '` 中。
 注意：`my_str.find("more", 0, len(my_str))` = `my_str.find("more")
```

在指定区间内查找指定字符：



```python
my_str = 'you are more than what you have become '
result = my_str.find("more", 0, 7)
print(result)

############## 运行结果 ###############

-1
```

- `my_str.find("more", 0, 7)` ：查找字符串 `more` 是否在`'you are more than what you have become '`前7个字符中，不存在就返回 -1。

### (2) index

> **index: 根据指定字符串，获取字符串所对应的下标**



```python
my_str = "hello"
result = my_str.index("h", 0, 2)

print(result)

############## 运行结果 ###############

0
my_str.index("查找的指定字符串", 开始下标, 结束下标[不包含])
```

- `my_str.index("h", 0, 2)`：查找 `h` 是否存在 `hello` 中前两个字符中，如果存在返回字符串所对应的下标。

如果查找的字符串不存在 find 会返回 -1 ，但这里会报错：



```python
my_str = "hello"
result = my_str.index("l", 0, 2)
print(result)

############## 运行结果 ###############

ValueError: substring not found
```

`my_str.index("l", 0, 2)`：查找 `l` 在 `hello` 前两个字母中所对应的下标，没有找到指定字符串就报错。

### (3) count

> **count: 统计指定字符串出现次数**



```python
my_str = "hello"
result = my_str.count("l", 0, 3)
print(result)
result = my_str.count("l")
print(result)

############## 运行结果 ###############

1
2
my_str.count("统计的指定字符串", 开始下标, 结束下标[不包含])
```

- `my_str.count("l", 0, 3)`：统计字符串`l`在`hello`中前三个字符中出现的次数；
- `my_str.count("l")`：统计字符串`l`在`hello`中出现的次数
   ``

### (4) replace

> **replace: 根据指定字符串进行替换**



```python
my_str = "hello"
result = my_str.replace("l", "w", 1)
print(result)
result = my_str.replace("l", "w", 2)
print(result)
result = my_str.replace("l", "w")
print(result)

############## 运行结果 ###############

hewlo
hewwo
hewwo
my_str.replace("要替换的字符串", "替换后的字符串", 替换的次数[默认是全部替换，1表示替换1次])
```

- `my_str.replace("l", "w", 1)`： 将`hello`中的 `l` 替换成 `w` 只替换一次；
- `my_str.replace("l", "w")`：将`hello`中的 `l` 全部替换成 `w`

### (5) split

> **根据指定字符串进行分割数据，返回是一个列表**



```python
my_str = "苹果,橘子,香蕉"
result = my_str.split(",", 1)
print(result, type(result))

############## 运行结果 ###############

['苹果', '橘子,香蕉'] <class 'list'>
my_str.split("指定分割的字符串", 分割的次数[默认是-1表示全部分割,1表示分割1次])
```

- `my_str.split(",", 1)`：将字符串`my_str = "苹果,橘子,香蕉"`按照指定字符：`,` 进行分割一次



```python
my_str = "苹果,橘子,香蕉"
result = my_str.split(",")
print(result, type(result))

############## 运行结果 ###############

['苹果', '橘子', '香蕉'] <class 'list'>
```

- `my_str.split(",")`：将字符串`my_str = "苹果,橘子,香蕉"`按照指定字符：`,` 全部分割。

### (6) startswith

> startswith: 判断是否是以指定字符串开头



```python
my_str = "http://www.baidu.com"
result = my_str.startswith("ftp://")
print(result)

############## 运行结果 ###############

False
```

- `my_str.startswith("ftp://")`：判断 字符串`my_str = "http://www.baidu.com"` 是否以`ftp://`开头

### (7) endswith

> **endswith: 判断是否是以指定字符串结尾**



```python
my_str = "http://www.baidu.com"
result = my_str.endswith("com")
print(result)

############## 运行结果 ###############

True
```

- `my_str.endswith("com")`：判断字符串 `my_str = "http://www.baidu.com"` 是否以`com`结尾。

### (8) lstrip - 去除左边空格



```python
my_str = "    abc    "
print(my_str)
# 去除左边空格
result = my_str.lstrip()
print(result)

############## 运行结果 ###############

    abc    
abc    
```

### (9) rstrip - 去除右边空格



```python
my_str = "    abc    "
print(my_str)
# 去除右边空格
result = my_str.rstrip()
print(result)

############## 运行结果 ###############

    abc    
    abc
```

### (10) strip - 去除两边空格



```python
my_str = "    abc    "
print(my_str)

# 去除两边空格
result = my_str.strip()
print(result)

############## 运行结果 ###############

    abc    
abc
```

去除左边、右边、两边的空格总体效果：



```python
my_str = "    abc    "
print(my_str)

result = my_str.lstrip()   ##去除左边空格
print(result)

result = my_str.rstrip()  ##去除右边空格
print(result)

result = my_str.strip()  ##去除两边空格
print(result)

############## 运行结果 ###############

    abc    
abc    
    abc
abc
```

### (11) rfind - 根据指定数据从右往左查找返回对应的下标

> 根据指定数据从右往左查找返回对应的下标，如果没有该指定数据则返回-1



```python
my_str = "asssabc"

result = my_str.rfind("x")  ##my_str中没有x，所以会返回-1
print(result)

result = my_str.rfind("c") ##my_str中c对应的下标是6
print(result)
############## 运行结果 ###############

-1
6
```

### (12) partition

> partition: 根据指定分割符，把数据分割成三部分， 返回的是一个元组。



```python
my_str = "abc&abc"
## 根据指定分隔符&，将字符串分割成三部分， 返回的是一个元组
result = my_str.partition("&")

print(result)
print(result,type(result))

############## 运行结果 ###############

('abc', '&', 'abc')
('abc', '&', 'abc') <class 'tuple'>
```

### (13) splitlines - 根据换行符进行分割



```python
my_str = "abc\nbcd\nedf"
result = my_str.splitlines()

print(result)
print(type(result))

############## 运行结果 ###############

['abc', 'bcd', 'edf']
<class 'list'>
```

只分割第一个换行符，后面的不分割：



```python
my_str = "abc\nbcd\nedf"

result = my_str.split("\n", 1)  ##只分割第一个换行符
print(result)

############## 运行结果 ###############

['abc', 'bcd\nedf']
```

### (14) isdigit - 判断字符串中是否只包含数字



```python
my_str = "123"
# 判断字符串中是否只包含数字
result = my_str.isdigit()
print(result)

############## 运行结果 ###############

True
```

### (15) join

> **根据指定字符串完成字符串的拼接，返回的是一个新的字符串。**

比如，我们有一个字符串`abc`，我们想把它变成`a,b,c`，就可以用`join`来实现：



```python
my_str = "abc"

# 根据指定字符串(逗号)完成对容器类型(字符串，列表，元组)中的每一个数据进行拼接，返回的是一个字符串
result = ",".join(my_str)
print(result)
print(type(result))

############## 运行结果 ###############

a,b,c
<class 'str'>
```

**注意：**使用`join`方法，容器类型中的每个数据都是字符串，也就是说列表中的每个数据，元组中的每个数据都要是字符串。

如果想要拼接的数据不是字符串类型，那就会报错：



```python
my_list = ["苹果", 10086]

# 列表里的第二个数据10086不是字符串类型
result = "!".join(my_list)
print(result)

############## 运行结果 ###############

Traceback (most recent call last):
  File "C:/Users/huangjing00liang/Desktop/黑马Python45期/第03天-字符串、列表/04-代码/day03/练习.py", line 4, in <module>
    result = "!".join(my_list)
TypeError: sequence item 1: expected str instance, int found
```

发现报错 `expected str instance, int found`：想要字符串`str`，但发现是`int`

我们把列表里的内容`my_list = ["苹果", 10086]`，全部改成字符串类型`my_list = ["苹果", "10086"]`，就不会报错：



```python
my_list = ["苹果", "10086"]
result = "!".join(my_list)

print(result)

############## 运行结果 ###############

苹果!10086
```

# 列表

> 列表最外层的表现形式是一对中括号，列表可以存储多个任意类型的数据，好比数据容器。

**列表可以储存任意多个类型的数据：**



```python
my_list = [1, 3.14, "abc", True]
print(my_list, type(my_list))

############## 运行结果 ###############

[1, 3.14, 'abc', True] <class 'list'>
```

**可以根据下标获取列表中的数据：**



```python
# 根据下标获取列表中的数据
my_list = [1, 3.14, "abc", True]
result = my_list[-2]
print(result)

############## 运行结果 ###############

abc
```

**列表还可以结合切片使用：**



```python
# 根据下标获取列表中的数据
my_list = [1, 3.14, "abc", True]
result = my_list[2:4]
print(result)

############## 运行结果 ###############

['abc', True]
```

**可以定义一个空列表，留着后面放数据：**



```python
my_list = []
print(my_list, type(my_list))

############## 运行结果 ###############

[] <class 'list'>
```

### 1、列表的遍历

> 列表的遍历可以使用`for`循环和`while`循环，推荐：`for`循环更加方便和简单。

#### 使用for循环遍历列表中的每一个数据



```python
my_list = [1, 3.14, "abc", True, [1, 3, 5]]

# 使用for循环遍历列表中的每一个数据
for value in my_list:
    # 打印每次遍历的数据
    print(value)

############## 运行结果 ###############

1
3.14
abc
True
[1, 3, 5]
```

#### 使用while循环遍历列表中的每个数据



```python
my_list = [1, 3.14, "abc", True, [1, 3, 5]]

index = 0
while index <= 4:
    # 根据下标获取对应的数据
    result = my_list[index]
    print(result)
    index += 1

############## 运行结果 ###############

1
3.14
abc
True
[1, 3, 5]
```

### 2、列表的增删改查

> 列表的添加，删除，修改，查看[根据下标获取数据]数据

#### append: 列表的末尾追加一个元素



```python
my_list = []
print(my_list)

## append: 列表的末尾追加一个元素
my_list.append("晁盖")
print(my_list)

my_list.append("宋江")
print(my_list)

############## 运行结果 ###############

[]
['晁盖']
['晁盖', '宋江']
```

#### insert: 根据下标插入指定数据



```python
my_list = ["晁盖", "宋江"]
print(my_list)

#在下标为0的位置插入“林冲”
my_list.insert(0, "林冲")
print(my_list)

############## 运行结果 ###############

['晁盖', '宋江']
['林冲', '晁盖', '宋江']
```

#### extend: 对指定的列表进行扩展



```python
my_list = ["晁盖", "宋江"]
my_list1 = ["鲁智深", "李逵", "武松"]

#把my_list1里面的每一个元素(数据)添加到my_list列表中
my_list.extend(my_list1)
print(my_list)

############## 运行结果 ###############

['晁盖', '宋江', '鲁智深', '李逵', '武松']
```

#### 根据下标修改数据



```python
my_list = ["晁盖", "宋江"]
print(my_list)

##根据下标修改列表中第二个数据
my_list[1] = "及时雨宋江"
print(my_list)

############## 运行结果 ###############

['晁盖', '宋江']
['晁盖', '及时雨宋江']
```

#### 根据切片修改多个数据



```python
my_list = ["林冲", "晁盖", "鲁智深", "李逵"]
print(my_list)

## 使用切片同时修改列表中前两个数据
my_list[0:2] = ["豹子头林冲", "天王晁盖"]
print(my_list)

############## 运行结果 ###############

['林冲', '晁盖', '鲁智深', '李逵']
['豹子头林冲', '天王晁盖', '鲁智深', '李逵']
```

### 删除列表中的数据[del， remove, pop]

#### del 根据下标删除数据



```python
my_list = ["林冲", "晁盖", "鲁智深", "李逵"]
print(my_list)

##删除下标是2的即第3个数据
del my_list[2]
print(my_list)

############## 运行结果 ###############

['林冲', '晁盖', '鲁智深', '李逵']
['林冲', '晁盖', '李逵']
```

#### del 根据切片删除多个数据



```python
my_list = ["林冲", "晁盖", "鲁智深", "李逵"]
print(my_list)

del my_list[1:3]
print(my_list)

############## 运行结果 ###############

['林冲', '晁盖', '鲁智深', '李逵']
['林冲', '李逵']
```

#### remove 根据列表中的元素删除数据



```python
my_list = ["林冲", "晁盖", "鲁智深", "李逵"]
print(my_list)

my_list.remove("鲁智深")
print(my_list)

############## 运行结果 ###############

['林冲', '晁盖', '鲁智深', '李逵']
['林冲', '晁盖', '李逵']
```

#### pop 根据下标删除数据并显示删除的数据

> 又想根据下标删除数据又想知道删除的数据是什么，以防删错了，这时用`pop`参数就能完成。



```python
my_list = ["林冲", "晁盖", "鲁智深", "李逵"]
print(my_list)

result = my_list.pop()  ##不指定下标，默认删除最后一个元素
print(result, my_list)

############## 运行结果 ###############

['林冲', '晁盖', '鲁智深', '李逵']
李逵 ['林冲', '晁盖', '鲁智深']
```

#### 根据下标查看(获取)指定数据



```python
my_list = ["林冲", "晁盖", "鲁智深", "李逵"]
result = my_list[0:2]

print(result)

############## 运行结果 ###############

['林冲', '晁盖']
```

### 3、in 和 not in 结合列表使用

> in: 判断指定数据是否在列表里面



```python
# 存储多个用户的姓名
my_list = []

for _ in range(3):
    name = input("请输入您添加姓名:")
    my_list.append(name)

print(my_list)

# 判断是否有要查找的数据
search_name = input("请输入您要查询的姓名:")

result = search_name in my_list
if result:
    print("找到了这个人")
else:
    print("没有找到该人")

############## 运行结果 ###############

请输入您添加姓名:张三
请输入您添加姓名:李四
请输入您添加姓名:王五
['张三', '李四', '王五']
请输入您要查询的姓名:黄晶
没有找到该人
```

以上操作就是将输入的三个用户名：'张三', '李四', '王五' ，存放在列表`my_list`，然后使用 `in`  结合列表查找指定用户是否在列表里。

> - not in : 判断指定数据不在列表里面



```python
name_list = ["A", 1, 3.14]

# 3.16 不在指定列表中
result = 3.16 not in name_list
print(result)

############## 运行结果 ###############

True
```

### 4、index 和 count 方法结合列表使用

> index: 根据指定数据在列表中获取数据对应的下标



```python
my_list = ["曹操", "荀彧", "贾诩"]

# 返回指定数据所对应的下标
result = my_list.index("荀彧")
print(result)

############## 运行结果 ###############

1
```

> count: 统计指定数据在列表中出现的次数



```python
my_list = ["曹操", "荀彧", "贾诩", "马忠", "孙权", "马忠"]

# 统计指定数据在列表中出现的次数
result = my_list.count("马忠")
print(result)

############## 运行结果 ###############

2
```

### 4、reverse 和 sort 方法结合列表使用

> reverse：将列表反转



```python
my_list = [1, 3, 2, 4]
print(my_list)

# 列表反转
my_list.reverse()
print(my_list)

############## 运行结果 ###############

[1, 3, 2, 4]
[4, 2, 3, 1]
```

**注意：`reverse`方法没有提供返回值，查看数据直接使用之前的变量即可**
 所以如果使用一个新的变量放`reverse`反转后的结果就会返回空`None`：



```python
my_list = [1, 3, 2, 4]
print(my_list)

##`reverse`方法没有返回值
result = my_list.reverse()
print(result)

############## 运行结果 ###############

[1, 3, 2, 4]
None
```

> sort ：将列表进行排序，默认从小到大 -> 升序



```python
my_list = [1, 3, 2, 4]
print(my_list)

my_list.sort()
print(my_list)

############## 运行结果 ###############

[1, 3, 2, 4]
[1, 2, 3, 4]
```

**对列表里面的内容先排序再反转：**



```python
my_list = [1, 3, 2, 4]
print(my_list)

# 排序，默认从小到大 -> 升序
my_list.sort()
print(my_list)

# 对排序后的数据进行反转
my_list.reverse()
print(my_list)

############## 运行结果 ###############

[1, 3, 2, 4]    ##自己定义的列表
[1, 2, 3, 4]    ##排序后的结果
[4, 3, 2, 1]    ##对排序后的结果再进行反转
```

### 5、列表的嵌套

> 列表嵌套：在一个列表里面再次使用一个列表



```python
city_list = []

# 南方城市列表
south_list = ["上海", "深圳", "广州"]
# 北方城市列表
north_list = ["北京", "天津", "济南"]

# 添加数据
city_list.append(south_list)
city_list.append(north_list)

print(city_list)

############## 运行结果 ###############

[['上海', '深圳', '广州'], ['北京', '天津', '济南']]
```

上面就是在一个大列表`city_list`里，嵌套着两个子列表：`south_list`和 `north_list`

##### 提取大列表中的子列表：



```python
city_list = [['上海', '深圳', '广州'], ['北京', '天津', '济南']]
north_list = city_list[1]
print(north_list)

############## 运行结果 ###############

['北京', '天津', '济南']
```

##### 提取大列表中子列表中元素：

比如，我想把列表`city_list = [['上海', '深圳', '广州'], ['北京', '天津', '济南']]`中的`天津`取出来：



```python
city_list = [['上海', '深圳', '广州'], ['北京', '天津', '济南']]

##取大列表中的子列表中的元素
city_name = city_list[1][1]
print(city_name)

############## 运行结果 ###############

天津
```

## 列表的应用

> **思考：一个学校，有3个办公室，现在有8位老师等待工位的分配，请编写程序，完成随机的分配**



```python
#导入模块random，它可以随机产生数字
import random

# 1. 三个办公室，办公室是可以容纳老师的，所以每一个办公室就是一个小列表
# my_list1 = []
# my_list2 = []
# my_list3 = []

# 办公室列表，里面的每个元素表示一个办公室，每个办公室还是一个列表
office_list = [[], [], []]

# 2. 8位老师，可以定义一个老师列表，存储8位老师
teacher_list = ["刘老师", "王老师", "郭老师", "马老师", "牛老师", "杨老师", "朱老师", "侯老师"]

# 3. 依次获取老师列表中的每一位老师，然后把老师随机分配到指定办公室
for teacher in teacher_list:

    # 生产随机数字，随机数字就是办公室的下标
    index = random.randint(0, 2)
    print(teacher, index)

    # 根据生产的下标获取对应的办公室
    office = office_list[index]

    # 把老师添加到随机的办公室里面
    office.append(teacher)

# 查看办公室信息
print(office_list)

############## 运行结果 ###############

刘老师 1
王老师 1
郭老师 1
马老师 2
牛老师 1
杨老师 1
朱老师 0
侯老师 0
[['朱老师', '侯老师'], ['刘老师', '王老师', '郭老师', '牛老师', '杨老师'], ['马老师']]
```

> **再思考：请优化第一步的代码使我们可以查看每个办公室的信息**



```python
import random

# 1. 三个办公室，办公室是可以容纳老师的，所以每一个办公室就是一个小列表
# my_list1 = []
# my_list2 = []
# my_list3 = []

# 办公室列表，里面的每个元素表示一个办公室，每个办公室还是一个列表
office_list = [[], [], []]

# 2. 8位老师，可以定义一个老师列表，存储8位老师
teacher_list = ["刘老师", "王老师", "郭老师", "马老师", "牛老师", "杨老师", "朱老师", "侯老师"]

# 3. 依次获取老师列表中的每一位老师，然后把老师随机分配到指定办公室
for teacher in teacher_list:

    # 生产随机数字，随机数字就是办公室的下标
    index = random.randint(0, 2)

    # 根据产生的下标获取对应的办公室
    office = office_list[index]

    # 把老师添加到随机的办公室里面
    office.append(teacher)

# 查看办公室信息
print(office_list)

num = 1
for office in office_list:
    # 查看每一个办公室，每个办公室是一个列表

    # 记录办公室老师的个数
    count = 0
    for _ in office:
        count += 1

    print("第%d个办公室总人数为:%d人" % (num, count))

    # 遍历办公室，获取每一个老师信息
    for teacher in office:
        # 查看每一个老师的信息
        print(teacher)

    num += 1

############## 运行结果 ###############

[['王老师', '杨老师'], ['刘老师', '郭老师', '朱老师'], ['马老师', '牛老师', '侯老师']]
第1个办公室总人数为:2人
王老师
杨老师
第2个办公室总人数为:3人
刘老师
郭老师
朱老师
第3个办公室总人数为:3人
马老师
牛老师
侯老师
```