## 1. if 语句的使用

#### if 语句的格式：



```python
if 判断的条件:
    条件成立会执行if语句里面的代码
```

举例：



```python
age = 18
if age >= 18:
    print("你已成年")

############## 运行结果 ###############

你已成年
```

## 2. 比较运算符

> 学习比较运算符的目的是比较运算符通常结合 `if` 语句使用.

python中的比较运算符如下表：



![img](https:////upload-images.jianshu.io/upload_images/15992481-6e40de8554ff54c6.png?imageMogr2/auto-orient/strip|imageView2/2/w/976/format/webp)



我们举例来看一下他们的共同点：



```python
num1 = 1
num2 = 2
# 判断两个变量的值是否相等
result = num1 == num2 # 因为有等号，先看等号右边的代码，把比较后的结果赋值给等号左边的变量
print(result, type(result))

result = num1 != num2
print(result, type(result))

result = num1 > num2
print(result, type(result))

result = num1 < num2
print(result, type(result))

result = num1 >= num2
print(result, type(result))

result = num1 <= num2
print(result, type(result))

############## 运行结果 ###############

False <class 'bool'>
True <class 'bool'>
False <class 'bool'>
True <class 'bool'>
False <class 'bool'>
True <class 'bool'>
```

**总结：比较运算符返回的结果bool类型，bool类型只有两个值: True, False**

- True 表示条件成立，if 语句里面的代码会执行；
- False表示条件失败，if 语句里面的代码不会执行

比如：



```python
num3 = 1
num4 = 2

if num3 != num4:
    print("条件成立")

############## 运行结果 ###############

条件成立
```

## 3. 逻辑运算符

- and：左右表达式都为True，整个表达式结果才为True；
- or：左右表达式有一个为True，整个表达式结果就为True；
- not：将右边表达式的逻辑结果取反，Ture变为False，False变为True

#### and

> and : 左右两边的条件都要成立，if 语句才会执行



```python
name = "西施"
age = 25

if name == "西施" and age == 25:
    print("找到女神了!")

############## 运行结果 ###############

找到女神了!
```

#### or

> or: 表示只要左右两边有一个条件成立，if语句就会执行



```python
name = "西施"
age = 25
if name == "貂蝉" or age < 38:
    print("找到你们啦")

############## 运行结果 ###############

找到你们啦
```

#### not

> not True 等于 False ， not False 等于 True



```python
result = not False
print(result)

############## 运行结果 ###############

True
```

举例：



```python
num = -1
if not num > 0:
    print("条件成立")

############## 运行结果 ###############

条件成立
```

**总结：逻辑运算符通常也是结合 if 语句来使用，主要是可以判断多个条件的关系**

## 4. if-else的使用

> **if - else 判断规则：当条件成立会执行 if 语句，条件不成立会执行 else 语句**

> 需求1：从键盘上获取年龄，判断是否大于或者等于18岁，如果满足就输出“你已成年”；如果不满足就输出“尚未成年”

思路：使用`input`从键盘中获取数据，并且存入到一个变量中 ---> 使用`if`语句，来判断`age>=18`是否成立：



```python
# 使用input从键盘中获取数据
age = int(input("请输入您的年龄:"))

# 判断年龄
if age >= 18:
    # 条件成立会执行if语句
    print("你已成年")
else:
    # 条件不成立会执行else语句
    print("尚未成年")
```

> 需求2：从键盘输入身高，如果身高没有超过150cm，则输出“不用买票”，否则输出“需要买票”。



```python
height = int(input("请输入您的身高(cm):"))

if height <= 150:
    print("不用买票")
else:
    print("需要买票")
```

# 5. if...elif...else...的使用

> 需求：根据学生分数判断分级，当分数为[90, 100]时为“优秀”；[80, 90)时为“良好”；[70, 80)时为“一般”；[60, 70)时为“及格”；60分以下为“不及格”



```python
# 接收分数
score = int(input("请输入您的分数:"))
# 判断分数
if score >= 90 and score <= 100:
    print("优秀")
elif score >= 80 and score < 90:
    print("良好")
elif score >= 70 and score < 80:
    print("一般")
elif score >= 60 and score < 70:
    print("及格")
else:
    print("不及格")
```

**注意：**

- 当某个条件成立时，会执行对应的条件语句里面的代码，其他条件判断不会执行。
- else 语句是可选的，可以根据自己的需求判断是否需要加上else语句。

## 6. 三目运算操作

*这个知识点不重要，知道有这么回事就行*

> 三目运算操作主要是简化 if - else 语句代码的



```python
num1 = 1
num2 = 2

# 使用两个变量中的最大值
if num1 > num2:
    print("num1:", num1)
else:
    print("num2:", num2)
```

上面这个 if - else 语句可以使用三目运算进行简化：



```python
num1 = 1
num2 = 2
# 使用三目运算操作对if-else语句进行简化操作
result = num1 if num1 > num2 else num2
print(result)
```

## 7. if 语句的嵌套

> if 语句的嵌套：在 if 语句里面再次使用 if 语句

if嵌套语句的应用

> 场景描述1：进车站必须同时满足两个条件，第一查看是否有票，第二查看是否带有违禁物品。



```python
ticket = 1     # 用1代表有车票，0代表没有车票
knife_length = 9     # 刀子的长度，单位为cm

if ticket == 1:
    print("有车票，可以进站")
    if knife_length < 10:
        print("通过安检")
    else:
        print("没有通过安检")
        print("刀子的长度超过规定，等待警察处理...")
else:
    print("没有车票，不能进站")

#### 输出为 #####

有车票，可以进站
通过安检
```

> 场景描述：某男生找女朋友，有两个条件：首先判断性别是否为“女”，然后判断年龄是否在24-27之间



```python
sex = input("请输入您的性别:")
if sex == "女":
    print("性别匹配")
    # 判断年龄
    age = int(input("请输入您的年龄:"))
    if age >= 24 and age <= 28:
        print("确认过眼神，你就是我要找的人")
    else:
        print("不好意思，打扰了!")
else:
    print("我们只要女生")
```

## 8. if语句的嵌套应用—猜拳游戏

> **需求：**
>
> - 从控制台输⼊要出的拳 —— 石头（1）／剪刀（2）／布（3）
> - 电脑随机出拳
> - 比较胜负

**知识点：**在 Python 中，要使用随机数，首先需要导入随机数的模块 —— “⼯具包”



```python
import random
```

导入模块后，可以直接在模块名称后面敲⼀个`.` 然后按`Tab` 键，会提示该模块中包含的所有函数，其中**`random.randint(a, b)`可以随机返回[a, b]之间的任意一个整数，包含 a 和 b**

使用规则如下：



```python
import random
value = random.randint(1, 3)
print(value)
```

代码实现猜拳游戏需求：



```python
import random

# 1. 接收用户输入的拳
player = int(input("请出拳 石头(1) 剪刀(2) 布(3):"))

# 2. 让电脑随机出拳 随机产生1-3的数字
computer = random.randint(1, 3)

# 3. 比较胜负, 胜负结果有三种情况(1. 你赢了, 2. 平局， 3. 你输了)
if (player == 1 and computer == 2) or (player == 2 and computer == 3) or (player == 3 and computer == 1):
    print("你赢了!")
elif player == computer:
    print("平局！")
else:
    print("你输了！")
```

# 循环语句

> **循环语句就是在程序中可以重复执行某段代码，循环语句有 while 、 for**

#### 循环语句应用场景

跟媳妇承认错误，说一万遍"媳妇儿，我错了"



```python
print("媳妇儿，我错了")
print("媳妇儿，我错了")
print("媳妇儿，我错了")
...(还有99997遍)...
```

使用循环语句一句话搞定：



```python
i = 0
    while i < 10000:
        print("媳妇儿，我错了")
        i += 1
```

小总结：

- while 和 if 的用法基本类似，区别在于：if 条件成立，则执行一次； while 条件成立，则重复执行，直到条件不成立为止。
- 一般情况下，需要多次重复执行的代码，都可以用循环的方式来完成

## 1. while循环语句

**注意点：**

- while循环会重复判断条件是否成立，只要条件成立那么循环语句里面的代码就会执行，当条件不成立时循环语句执行结束
- 如果次数不没有进行控制，会出现死循环，死循环的原因就是条件始终成立
- if 语句只会判断一次条件，while 循环语句会重复判断条件是否成立

> 需求：循环打印5次“人生苦短，我用Python”



```python
num = 0
while num < 5:
    print("人生苦短，我用Python")
    num += 1

#### 输出为 #####

人生苦短，我用Python
人生苦短，我用Python
人生苦短，我用Python
人生苦短，我用Python
人生苦短，我用Python
```

## 2. while循环练习

> 练习1：循环打印5次，显示当前循环的次数



```python
count = 1

while count <= 5:
    print("当前循环的次数: %d" % count)
    count += 1

#### 输出为 #####

当前循环的次数: 1
当前循环的次数: 2
当前循环的次数: 3
当前循环的次数: 4
当前循环的次数: 5
```

> 练习2：倒着循环打印5次，显示当前循环的次数



```python
count = 5

while count >= 1:
    print("当前循环的次数: %d" % count)
    count -= 1

#### 输出为 #####

当前循环的次数: 5
当前循环的次数: 4
当前循环的次数: 3
当前循环的次数: 2
当前循环的次数: 1
```

> 练习3：计算1~100的累加和（包含1和100）



```python
# 1. 生成1-100之间的数字
# 记录每次生成的数字
num = 1
# 记录累加的和
result = 0
while num <= 100:
    # 循环生成1-100之间的数字
    # 2. 把每一个数字累加起来
    result += num
    num += 1
# 当循环执行结束的时候，累加和计算完成
print("结果为:", result)

#### 输出为 #####

结果为: 5050
```

> 练习4：计算1~100之间偶数的累加和



```python
result = 0
# 1. 生成1-100之间的数字
num = 1
while num <= 100:
    # 2. 判断数字是否是偶数
    if num % 2 == 0:
        # 3. 把所有偶数累加起来
        result += num
    num += 1
print("偶数和结果:", result)

#### 输出为 #####

偶数和结果: 2550
```

## 3. while循环嵌套

> while 循环嵌套: 在 while 循环语句里面再次使用 while 循环语句

> 需求：循环三次，每循环一次打印三次 “人生苦短，我用python”



```python
count = 1

while count <= 3:
    print("当前的循环的次数: %d" % count)

    # 让人生苦短信息循环执行三次
    num = 1
    while num <= 3:
        print("人生苦短，我用python")
        num += 1

    count += 1

#### 输出为 #####

当前的循环的次数: 1
人生苦短，我用python
人生苦短，我用python
人生苦短，我用python
当前的循环的次数: 2
人生苦短，我用python
人生苦短，我用python
人生苦短，我用python
当前的循环的次数: 3
人生苦短，我用python
人生苦短，我用python
人生苦短，我用python
```

## 4.  while循环嵌套应用

> 要求1：打印如下图形
>
> ![img]()



```python
循环控制打印的行数
# 记录当前的行数
row = 1

while row <= 5:
    # print("当前是第%d行" % row)
    # 记录当前的列数
    col = 1
    while col <= 5:
        print("*", end=" ")
        col += 1
    # 提示：当内层循环执行结束，说明当前这一行星星打印完毕，换行打印星星
    print("")
    row += 

#### 输出为 #####

* * * * * 
* * * * * 
* * * * * 
* * * * * 
* * * * *
```

> 要求2：打印如下图形
>
> ![img]()



```python
# 记录当前行数
row = 1

# 外层循环控制行数
while row <= 5:

    # 内层循环控制列数
    col = 1
    while col <= row:
        print("*", end=" ")
        col += 1

    # 内层循环结束表示当前这一行星星打印完毕，需要换行打印下一行星星
    print("")
    row += 1

#### 输出为 #####

* 
* * 
* * * 
* * * * 
* * * * *
```

## 5. for循环

> 像 while 循环一样，for 可以完成循环的功能。在Python中 **for循环可以遍历任何序列的项目，如一个列表或者一个字符串等。**

#### for循环的格式



```python
for 临时变量 in 列表或者字符串等可迭代对象:
    循环满足条件时执行的代码
```

#### for循环应用—遍历容器类型中的每一个数据



```python
my_str = "hello"
# 通过for循环可以方便的获取字符串中的每一个数据
for value in my_str:
    # 依次查看value获取的每一个数据
    print(value)

#### 输出为 #####

h
e
l
l
o
```

**for 循环内部可以结合 if 语句使用**



```python
my_str = "hello"
for value in my_str:
    # 依次查看value获取的每一个数据
    if value == "l":
        print("l出现了")
    else:
        print(value)

#### 输出为 #####

h
e
l出现了
l出现了
o
```

# 6. for 循环结合`range`使用

> - range 表示一个范围，也是属于容器类型
> - **for 循环结合`range`使用也可以让某段代码重复执行多次**

> - **range(5)：表示产生一个[0,5) => [0, 4]范围**



```python
for value in range(5):
    print("哈哈", value)

#### 输出为 #####

哈哈 0
哈哈 1
哈哈 2
哈哈 3
哈哈 4
```

> - **range(1, 4) ： 1—表示开始位置数据 ；4—表示结束位置数据 [结束位置数据不包含]**



```python
for value in range(1, 4):
    print("嘻嘻", value)

#### 输出为 #####

嘻嘻 1
嘻嘻 2
嘻嘻 3
```

> **range(1, 11, 2) ：第一个参数是开始位置数据，第二个参数是结束位置数据[不包含], 第三个参数步长：前后数据之间间隔**

提示：如果不指定步长默认1



```python
for value in range(1, 11, 2):
    print(value)

#### 输出为 #####

1
3
5
7
9
```

步长还可以指定为负数：



```python
for value in range(5, 0, -1):
    print(value)

#### 输出为 #####

5
4
3
2
1
```

**小但是有用的知识点：**如果使用`for`循环只是为了实现简单的循环，那循环中的变量可以使用下划线进行占位：



```python
for _ in range(3):
    print("嗯嗯")

#### 输出为 #####

嗯嗯
嗯嗯
嗯嗯
```

## 7. break 和 continue

- **`break`的作用：结束`break`所在的这层循环。**
- **`continue`的作用：用来结束本次循环，紧接着执行下一次的循环。**
- **`break` 和 `continue` 只能用在循环语句里面，不能单独使用。循环语句有：`while， for`**
- 当循环语句里面执行break，表示当前这层循环执行结束，break后面代码不能执行；
- 当循环语句执行了continue，表示本次循环执行结束，然后根据条件判断是否执行下一次循环。

## 8.循环语句结合else语句使用

- 当循环语句正常结束的时候else语句就会执行，否则else语句不会执行
   **循环语句正常结束：循环语句里面没有执行break， else语句会执行**
   **循环语句非正常结束：循环语句里面执行了break， else语句不会执行**
- 循环语句执行了 continue 关键字，else 语句依然可以执行

> **循环语句结合else语句使用的场景：**
>  在指定字符串里面查找对应的数据，如果找到了打印对应的数据，否则显示没有该数据。



```python
my_str = "hello"

for value in my_str:
    print(value)
    if value == "e":
        print("找到了:", value)
        break
else:
    print("没有找到该数据")

#### 输出为 #####

h
e
找到了: e
```

