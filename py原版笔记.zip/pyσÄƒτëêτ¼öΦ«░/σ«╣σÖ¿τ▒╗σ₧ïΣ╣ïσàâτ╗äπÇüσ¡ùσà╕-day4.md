# 元组 — tuple

> **元组：也是一个容器类型，可以存储多个任意类型的数据，元组好比是一个只读的列表，只能获取数据不能对元组中的数据进行修改。**
>  **元组的表现形式： (1, "3")，最外层表现形式是一对小括号**

```python
my_tuple = (1, 3.14, True, "abc", [1, 2], (1, 54))

print(my_tuple)
print(type(my_tuple))

#########  运行结果  ############

(1, 3.14, True, 'abc', [1, 2], (1, 54))
<class 'tuple'>
```

#### 不能对元组中的数据进行修改

如果对元组中的数据进行修改就会报错：

```python
my_tuple = (1, 3.14, True, "abc", [1, 2], (1, 54))

my_tuple[0] = 2
del my_tuple[-1]

print(my_tuple)

#########  运行结果  ############

TypeError: 'tuple' object does not support item assignment
```

> 注意：元组只能获取数据

#### 根据下标获取元组中的数据

```python
my_tuple = (1, 3.14, True, "abc", [1, 2], (1, 54))

result = my_tuple[0]
print(result)

result = my_tuple[-1]
print(result)

#########  运行结果  ############

1
(1, 54)
```

##### 元组的切片

> 字符串，列表，元组都有切片处理

```python
my_tuple = (1, 3.14, True, "abc", [1, 2], (1, 54))

result = my_tuple[1:4]
print(result)

#########  运行结果  ############

(3.14, True, 'abc')
```

**元组的使用场景：**

- 函数的返回值是元组，保证返回的数据不能修改
- print函数进行格式化输出的时候使用元组

通过元组给多个格式化占位符进行传参：



```python
print("我叫:%s 年龄:%d" % ("李四", 20))

#########  运行结果  ############

我叫:李四 年龄:20
```

元组的注意点：

- 元组里面的数据不能修改(添加，删除，修改)
- 当元组里面只有一个元素，元组里面的逗号不能省略

元祖中若只有一个元素时把后面的逗号省去了将不再是元祖类型：



```python
my_tuple = ("abc",)
my_tuple1 = ([1, 2],)


print(my_tuple, type(my_tuple))
print(my_tuple1, type(my_tuple1))

print("=== 元祖中只有一个元素把后面的逗号省去了将不再是元祖类型 ===")

my_tuple2 = ("abc")
my_tuple3 = ([1, 2])

print(my_tuple2, type(my_tuple2))
print(my_tuple3, type(my_tuple3))

#########  运行结果  ############

('abc',) <class 'tuple'>
([1, 2],) <class 'tuple'>
=== 元祖中只有一个元素把后面的逗号省去了将不再是元祖类型 ===
abc <class 'str'>
[1, 2] <class 'list'>
```

### index和count方法结合元组使用

#### count: 统计指定数据在元组里面的次数



```python
my_tuple = (1, 3, "1", 1)

# 统计指定数据1在元组里面出现的次数
result = my_tuple.count(1)
print(result)

#########  运行结果  ############

2
```

#### index: 根据指定数据，获取数据在元组的下标



```python
my_tuple = (1, 3, "1", 1)

# 元祖结合index使用获取数据3在元组的下标
result = my_tuple.index(3)

#########  运行结果  ############

1
```

### 元祖的遍历

#### for循环遍历元组中的每一个数据



```python
my_tuple = ('西施', "貂蝉", "王昭君", "杨玉环")

for value in my_tuple:
    print(value)

#########  运行结果  ############

西施
貂蝉
王昭君
杨玉环
```

#### while循环遍历元祖中的每一个数据



```python
my_tuple = ('西施', "貂蝉", "王昭君", "杨玉环")
index = 0
while index <= 3:
    result = my_tuple[index]
    print(result)
    index += 1

#########  运行结果  ############

西施
貂蝉
王昭君
杨玉环
```

扩展：`len`: 获取容器类型数据的长度， len函数获取字符串、列表、元组类型的个数



```python
my_tuple = ('西施', "貂蝉", "王昭君", "杨玉环")
number = len(my_tuple)
print(number)

#########  运行结果  ############

4
```

应用：



```python
my_tuple = ('西施', "貂蝉", "王昭君", "杨玉环")
##len函数获取元组的结束下标
index = len(my_tuple) - 1

while index >= 0:
    result = my_tuple[index]
    print(result)

    index -= 1

#########  运行结果  ############

杨玉环
王昭君
貂蝉
西施
```

扩展：反向输出



```python
my_tuple = ('西施', "貂蝉", "王昭君", "杨玉环")

result = my_tuple[::-1]
print(result)

#########  运行结果  ############

('杨玉环', '王昭君', '貂蝉', '西施')
```

# 字典 — dict

> 字典：也是一个容器类型，字典里面的每一个数据都是键值对(key:value), 字典的最外层表现形式: {key:value, ....}
>  学习字典的目的： 对于存储描述性信息可以使用字典，比如：存储学生信息，老师信息，教室信息，电脑信息

**注意：字典中的key是唯一的, 不能重复**

#### 定义字典



```python
my_dict = {"age": 20, "name": "李四",  "address": "北京", "sex": "女"}
print(my_dict, type(my_dict))

#########  运行结果  ############

{'age': 20, 'name': '李四', 'address': '北京', 'sex': '女'} <class 'dict'>
```

#### 通过key获取对应的value值



```python
my_dict = {"age": 20, "name": "李四",  "address": "北京", "sex": "女"}

value = my_dict["age"]
print(value)

sex = my_dict["sex"]
print(sex)

#########  运行结果  ############

20
女
```

**使用上面这种中括号方式获取字典中的value值，如果key不存在那么程序会报错**
 比如我们想要获取“李四”的学历（educational_history）字典中并没有：



```python
my_dict = {"age": 20, "name": "李四",  "address": "北京", "sex": "女"}

result = my_dict["educational_history"]
print(result)

#########  运行结果  ############

KeyError: 'educational_history'
```

#### get方式取值（value）

get方式取值可以提供默认值，如果字典有对应的key，获取key对应的value值，没有就使用默认值：



```python
my_dict = {"age": 20, "name": "李四",  "address": "北京", "sex": "女"}

# get方式取值,如果字典有对应的key就获取key对应的value值
value = my_dict.get("age")
print(value)

# 如果字典没有对应的key使用默认值
result = my_dict.get("educational_history", "硕士")
print(result)

#########  运行结果  ############

20
硕士
```

## 字典的增删改查

#### 添加键值对

> 注意点：如果操作的key在字典里面不存在，那么是添加键值对操作



```python
my_dict = {"name": "西施", "age": 25}
print(my_dict)

# 添加键值对 
my_dict["address"] = "杭州"
print(my_dict)

my_dict["sex"] = "女"
print(my_dict)

#########  运行结果  ############

{'name': '西施', 'age': 25}
{'name': '西施', 'age': 25, 'address': '杭州'}
{'name': '西施', 'age': 25, 'address': '杭州', 'sex': '女'}
```

#### 修改键值对

> 注意点：如果操作的key在字典里面，那么是修改键值对操作



```python
my_dict = {"name": "西施", "age": 25}
print(my_dict)

# 修改键值对，注意点：如果操作的key在字典里面，那么是修改键值对操作
my_dict["age"] = 20
print(my_dict)

#########  运行结果  ############

{'name': '西施', 'age': 25}
{'name': '西施', 'age': 20}
```

#### 删除键值对

##### del



```python
my_dict = {"name": "西施", "age": 25, "address": "杭州"}
print(my_dict)

##删除键值对
del my_dict["address"]
print(my_dict)

#########  运行结果  ############

{'name': '西施', 'age': 25, 'address': '杭州'}
{'name': '西施', 'age': 25}
```

##### pop

扩展：根据key删除键值对，并且返回key对应的value值



```python
my_dict = {"name": "西施", "age": 25, "address": "杭州"}
print(my_dict)

##pop有返回值
value = my_dict.pop("age")
print(value, my_dict)

#########  运行结果  ############

{'name': '西施', 'age': 25, 'address': '杭州'}
25 {'name': '西施', 'address': '杭州'}
```

#### 查看数据，获取数据



```python
my_dict = {"name": "西施", "age": 25, "address": "杭州"}

result1 = my_dict["name"]
result2 = my_dict["address"]
print(result1, result2)

#########  运行结果  ############

西施 杭州
```

#### 清除字典中的所有数据



```python
my_dict = {"name": "西施", "age": 25, "address": "杭州"}
print(my_dict)

##清除字典中的所有数据
my_dict.clear()
print(my_dict)

#########  运行结果  ############

{'name': '西施', 'age': 25, 'address': '杭州'}
{}
```

#### 清除列表中的所有数据



```python
my_list = [1, 3, 5]
print(my_list)

##清除列表中的所有数据
my_list.clear()
print(my_list)

#########  运行结果  ############

[1, 3, 5]
[]
```

扩展：列表里面通过 `extend` 完成列表的合并，字典里面通过 `update` 完成字典的合并

#### 字典的合并 — update



```python
my_dict1 = {"name": "貂蝉", "age": 20}
my_dict2 = {"sex": "女", "address": "无锡", "age": 25}
print(my_dict1)
print(my_dict2)

# 把my_dict2字典中的每一个键值对添加到my_dict1里面
print("====== 合并后 =====")
my_dict1.update(my_dict2)

print(my_dict1)

#########  运行结果  ############

{'name': '貂蝉', 'age': 20}
{'sex': '女', 'address': '无锡', 'age': 25}
====== 合并后 =====
{'name': '貂蝉', 'age': 25, 'sex': '女', 'address': '无锡'}
```

## 字典的常见的操作

#### len函数获取字典的个数

`len`函数还可以获取：字符串，列表，元组，字典的个数



```python
my_dict = {"name": "猪八戒", "sex": "男"}

# 获取字典的个数
result = len(my_dict)
print(result)

#########  运行结果  ############

2
```

#### keys方法获取字典中的所有key



```python
my_dict = {"name": "猪八戒", "sex": "男"}

# keys方法获取字典中的所有key
result = my_dict.keys()

# 返回的是dict_keys类型， 查看数据不方便，可以转换成list类型
print(result, type(result))

# 把dict_keys类型转成list
my_list = list(result)
print(my_list, type(my_list))

#########  运行结果  ############

dict_keys(['name', 'sex']) <class 'dict_keys'>
['name', 'sex'] <class 'list'>
```

#### values方法获取字典中的所有value



```python
my_dict = {"name": "猪八戒", "sex": "男"}

# values方法： 获取字典中的所有value
result = my_dict.values()
# 返回的类型是dict_values，查看数据不方便，可以转换成list类型
print(result, type(result))
my_list = list(result)
print(my_list, type(my_list))

#########  运行结果  ############

dict_values(['猪八戒', '男']) <class 'dict_values'>
['猪八戒', '男'] <class 'list'>
```

#### items方法获取字典中的所有项数据，每一项数据是一个键值对数据



```python
my_dict = {"name": "猪八戒", "sex": "男"}

result = my_dict.items()
# 返回的数据类型：dict_items，查看数据不方便可以转换list类型
print(result, type(result))

my_list = list(result)
print(my_list, type(my_list))

#########  运行结果  ############

dict_items([('name', '猪八戒'), ('sex', '男')]) <class 'dict_items'>
[('name', '猪八戒'), ('sex', '男')] <class 'list'>
```

## 字典的遍历

#### 遍历字典中的所有key

> ```python
> my_dict.keys()` 获取字典中的所有`key
> ```



```python
my_dict = {"name": "小明", "age": 18, "sex": "男", "address": "北京"}

# 遍历字典中的所有key
for key in my_dict.keys(): # my_dict.keys() 获取字典中的所有key

    # 根据key获取对应的value值
    value = my_dict[key]

    print(key, value)

#########  运行结果  ############

name 小明
age 18
sex 男
address 北京
```

#### 遍历字典中的所有value



```python
my_dict = {"name": "小明", "age": 18, "sex": "男", "address": "北京"}

for value in my_dict.values():
    print(value)

#########  运行结果  ############

小明
18
男
北京
```

#### 遍历字典中的所有项(item)



```python
my_dict = {"name": "小明", "age": 18, "sex": "男", "address": "北京"}

for item in my_dict.items():
    # 遍历的每项数据是一个元组类型，元组里面存放的是key和value
    print(item, type(item))
    # 根据下标获取元组中的数据
    # 获取key
    key = item[0]
    value = item[1]
    print(key, value)

#########  运行结果  ############

('name', '小明') <class 'tuple'>
name 小明
('age', 18) <class 'tuple'>
age 18
('sex', '男') <class 'tuple'>
sex 男
('address', '北京') <class 'tuple'>
address 北京
```

**遍历的每项数据是一个元组，使用不同变量保存元组中的每一个数据，这里是操作是拆包：**



```python
my_dict = {"name": "小明", "age": 18, "sex": "男", "address": "北京"}

for key, value in my_dict.items():
    print(key, value)

#########  运行结果  ############

name 小明
age 18
sex 男
address 北京
```

扩展： 直接遍历字典，默认取的是字典的key



```python
my_dict = {"name": "小明", "age": 18, "sex": "男", "address": "北京"}

for key in my_dict:
    print(key)

#########  运行结果  ############

name
age
sex
address
```

## enumerate函数的使用

> `enumerate`函数：当使用for循环遍历数据时，又想使用数据对应的下标又想使用数据就可以使用enumerate函数了。

如果不使用 `enumerate` 函数想要遍历数据时又获取下标又获取数据，就需要设置一个变量存放下标：



```python
my_list = ["a", "b", "c"]

# 记录当前数据的下标
index = 0
for value in my_list:
    print(index, value)
    index += 1

#########  运行结果  ############

0 a
1 b
2 c
```

使用enumerate函数就会方便很多：



```python
my_list = ["a", "b", "c"]

for item in enumerate(my_list): # enumerate(my_list)表示又取下标又取数据
    # 遍历的每项数据是一个元组
    print(item)

#########  运行结果  ############

(0, 'a')
(1, 'b')
(2, 'c')
```

遍历的每项数据是一个元组，对元组进行拆包处理：



```python
my_list = ["a", "b", "c"]

for index, value in enumerate(my_list):
    print(index, value)

#########  运行结果  ############

0 a
1 b
2 c
```

结合`break`语句使用：



```python
my_list = ["a", "b", "c"]

for index, value in enumerate(my_list): # enumerate(my_list)表示又取下标又取数据
    print(index, value)

    if index == 1:
        break

#########  运行结果  ############

0 a
1 b
```

扩展： enumerate可以结合列表，字符串，元组，字典

例如，enumerate结合字典：



```python
my_dict = {"name": "小明", "age": 18, "sex": "男", "address": "北京"}

for index, item in enumerate(my_dict.items()):
    if index == 2:
        break
    # 利用拆包，获取元组中的每项数据
    key, value = item
    print(key, value)

#########  运行结果  ############

name 小明
age 18
```

enumerate结合字符串：



```python
my_str = "hello"

for index, value in enumerate(my_str):
    print(index, value)

#########  运行结果  ############

0 h
1 e
2 l
3 l
4 o
```

> **字典的使用练习题：一个学校，有3个办公室，现在有8位老师等待工位的分配，请使用字典编写程序，完成随机的分配**



```python
import random

# 1. 三个办公室，办公室是可以容纳老师的，所以每一个办公室就是一个小列表
# my_list1 = []
# my_list2 = []
# my_list3 = []

# 办公室列表，里面的每个元素表示一个办公室，每个办公室还是一个列表
office_list = [[], [], []]

# 2. 8位老师，可以定义一个老师列表，存储8位老师
teacher_list = ["刘老师", "王老师", "郭老师", "马老师", "牛老师", "杨老师", "朱老师", "侯老师"]

# 3. 依次获取老师列表中的每一位老师，然后把老师随机分配到指定办公室
for teacher in teacher_list:

    # 生产随机数字，随机数字就是办公室的下标
    index = random.randint(0, 2)

    # 根据生产的下标获取对应的办公室
    office = office_list[index]

    # 把老师添加到随机的办公室里面
    office.append(teacher)

# 遍历办公室列表，获取每一个办公室
for index, office in enumerate(office_list):
    # 查看每一个办公室，每个办公室是一个列表

    num = index + 1
    # 获取办公室老师的个数
    count = len(office)
    print("第%d个办公室总人数为:%d人" % (num, count))

    # 遍历办公室，获取每一个老师信息
    for teacher in office:
        # 查看每一个老师的信息
        print(teacher)

    num += 1

#########  运行结果  ############

第1个办公室总人数为:2人
王老师
朱老师
第2个办公室总人数为:3人
郭老师
马老师
侯老师
第3个办公室总人数为:3人
刘老师
牛老师
杨老师
```

