# 1. 初识Python

## 1.1 编程语言和Python

#### 编程语言是什么？

是用来定义计算机程序的形式语言。我们通过编程语言来编写程序代码，再通过语言处理程序执行向计算机发送指令，让计算机完成对应的工作。

> **简单来说，编程语言就是人类和计算机进行交流的语言。**

#### 什么是Python？

Python就是一门编程语言，而且是现在世界上最流行的编程语言之一。

## 1.2 Python解释器

### 安装Python

首先登陆[Python官网](https://links.jianshu.com/go?to=https%3A%2F%2Fwww.python.org%2F)，在官网我们可以下载Python，[Python的安装视频](https://links.jianshu.com/go?to=https%3A%2F%2Fwww.bilibili.com%2Fvideo%2Fav51230273%3Ffrom%3Dsearch%26seid%3D12665192166727819012) 按照安装视频操作即可。

![img](https:////upload-images.jianshu.io/upload_images/15992481-f86af5dc01c54b2b.png?imageMogr2/auto-orient/strip|imageView2/2/w/1200/format/webp)

Python官网



### Python解释器

当我们编写Python代码时，我们得到的是一个包含Python代码的以`.py`为扩展名的文本文件。要运行代码，就需要Python解释器去执行`.py`文件。

在计算机内部，Python解释器把源代码转换成称为字节码的中间形式，然后再把它翻译成计算机使用的机器语言并运行。

#### Python解释器——CPython

当我们从[Python官方网站](https://links.jianshu.com/go?to=https%3A%2F%2Fwww.python.org%2F)下载并安装好Python 3.x后，我们就直接获得了一个官方版本的解释器：CPython。这个解释器是用C语言开发的，所以叫CPython。**在命令行下运行`python`就是启动CPython解释器。**CPython是使用最广的Python解释器。

#### Python解释器——IPython

IPython是基于CPython之上的一个交互式解释器，也就是说，IPython只是在交互方式上有所增强，但是执行Python代码的功能和CPython是完全一样的。好比很多国产浏览器虽然外观不同，但内核其实都是调用了IE。
 **CPython用`>>>`作为提示符，而IPython用`In [序号]:`作为提示符。**

#### 安装 IPython解释器

Linux操作系统下



![img](https:////upload-images.jianshu.io/upload_images/15992481-5a2ded4f64359d3d.png?imageMogr2/auto-orient/strip|imageView2/2/w/1074/format/webp)

https://ipython.org/install.html



```ruby
##安装 IPython解释器
(py3env) jhuang 16:51:09 ~ 
$ pip install ipython
```

出现以下显示，说明安装成功



```csharp
Successfully installed backcall-0.1.0 ipython-7.6.1 jedi-0.14.0 parso-0.5.0 pexpect-4.7.0 pickleshare-0.7.5 prompt-toolkit-2.0.9 ptyprocess-0.6.0 pygments-2.4.2 wcwidth-0.1.7
You are using pip version 9.0.1, however version 19.1.1 is available.
You should consider upgrading via the 'pip install --upgrade pip' command.
```

#### 启动iPython



```ruby
##启动iPython
(py3env) jhuang 17:08:48 ~/project/learn_python 
$ ipython
Python 3.5.4 |Continuum Analytics, Inc.| (default, Aug 14 2017, 13:26:58) 
Type 'copyright', 'credits' or 'license' for more information
IPython 7.6.1 -- An enhanced Interactive Python. Type '?' for help.

In [1]:   
```

**当提示符变为`In [1]:`时，ipython解释器启动成功。**

### Python解释器——Pycharm

> PyCharm 是一款功能强大的 Python 编辑器，在自己电脑上安装一个Pycharm软件写和运行Python脚本特别方便

## 1.3 用Pycharm编写第一个python程序

打开 Pycharm，选择 Create New Project，创建一个新项目



![img](https:////upload-images.jianshu.io/upload_images/15992481-00218b74e51ef8f8.png?imageMogr2/auto-orient/strip|imageView2/2/w/1200/format/webp)

Pycharm开始界面



选择Pure Python表示创建一个纯Python程序项目, Location 表示该项目保存的路径，Interpreter 表示使用的Python解释器版本，最后点击Create 创建项目。



![img](https:////upload-images.jianshu.io/upload_images/15992481-dca9d88182c53f73.png?imageMogr2/auto-orient/strip|imageView2/2/w/1200/format/webp)

创建Python项目


 右击项目，选择New，再选择Python File

![img](https:////upload-images.jianshu.io/upload_images/15992481-a4f6d11fa3533d13.png?imageMogr2/auto-orient/strip|imageView2/2/w/1200/format/webp)

创建Python文件



在弹出的对话框中输入的文件名HelloPython，点击OK，表示创建一个Python程序的文本文件，文本文件后缀名默认.py



![img](https:////upload-images.jianshu.io/upload_images/15992481-f4f931f36de36ca7.png?imageMogr2/auto-orient/strip|imageView2/2/w/706/format/webp)

为Python文件命名


 输入以下代码，并右击空白处，选择Run运行，表示打印一个字符串"Hello World!"：



```bash
print("Hello World!")
```

![img](https:////upload-images.jianshu.io/upload_images/15992481-57763c9cf5b2ebd3.png?imageMogr2/auto-orient/strip|imageView2/2/w/1200/format/webp)

运行Python代码



运行成功后，Pycharm Console窗口将显示我们的输出结果。



![img](https:////upload-images.jianshu.io/upload_images/15992481-0f73226de6fe0e27.png?imageMogr2/auto-orient/strip|imageView2/2/w/1200/format/webp)

显示输出结果

# Python基础知识

## 1. 注释

> - 注释：在程序代码中对程序代码进行解释说明的文字。
> - 作用：注释不是程序，不能被执行，只是对程序代码进行解释说明，让别人可以看懂程序代码的作用，能够大大增强程序的可读性。

### 注释的分类

#### 单行注释

以#开头，#右边的所有文字当作说明，而不是真正要执行的程序，起辅助说明作用



```bash
# 我是注释，可以在里写一些功能说明之类的哦
print('hello world')
```

#### 多行注释

两行`'''` （是英文状态下Enter左边那个键按三下）之间可以写多行注释



```python
'''
    我是多行注释，可以写很多很多行的功能说明

'''
```

注释分为：

- 1. 单行注释: 以 # 开头 ，注释内容只能写一行
- 1. 多行注释: 使用三引号，注释内容可以有多行

## 2. 变量以及类型

### 2.1变量的定义

> 变量：就是存储程序中数据的容器，就是用来存储数据的.

在程序中，有时我们需要对2个数据进行求和，那么该怎样做呢？
 答：需要把2个数据，或者多个数据进行求和的话，那么就需要把这些数据先存储起来，然后把它们累加起来即可

在Python中，存储一个数据，需要一个叫做变量的东西，如下示例:



```bash
num1 = 100  #num1就是一个变量，就好一个小菜篮子

num2 = 87   #num2也是一个变量

result = num1 + num2  #把num1和num2这两个变量中的数据进行累加，然后放到 result变量中
```

- 程序就是用来处理数据的，而变量就是用来存储数据的

### 2.2 变量的类型

为了更充分的利用内存空间以及更有效率的管理内存，变量是有不同的类型的，如下所示：

<img src="Python基础—Day1.assets/webp" alt="img" style="zoom:43%;" />

变量的类型

> 怎样知道一个变量的类型呢？

在python中，只要定义了一个变量，而且它有数据，那么它的类型就已经确定了，不需要咱们开发者主动的去说明它的类型，系统会自动辨别，可以使用type(变量的名字)，来查看变量的类型：



```bash
# int 型变量
num1 = 200
print(type(num1))

# 浮点型变量
num2 = 3.14
print(type(num2))

# 布尔型变量
my_bool = True
print(type(my_bool))

# 字符串型变量
my_str = 'hello'
print(type(my_str))

############## 输出结果 ###############

<class 'int'>
<class 'float'>
<class 'bool'>
<class 'str'>
```

## 3. 标识符和关键字

### 3.1 标识符

> 开发人员在程序中自定义的一些符号和名称，标识符是自己定义的，如变量名 、函数名等

- 标识符：通俗理解就是程序中的变量名和函数名等等
- 标识符的特点：见名知意
- 标识符的组成：字母、数字、下划线并且不能以数字开头
- python中的标识符是区分大小写的（Name 不等于 name）

#### 标识符（变量名）的命名规则：

- 小驼峰命名法：第一个单词首字母小写，其他单词的首字母都大写，如：myName、aDog
- 大驼峰命名法：每个单词首字母都大写，如：FirstName、LastName
- 下划线命名法：每个单词字母都小写，单词之间使用下划线进行分割   （推荐使用）如：my_name

### 3.2 关键字

- 关键字：具体特殊功能的标识符就是关键字
- 注意点：关键字不能作为变量名使用

查看关键字：



```kotlin
and     as      assert     break     class      continue    def     del
elif    else    except     exec      finally    for         from    global
if      in      import     is        lambda     not         or      pass
print   raise   return     try       while      with        yield
```

在Python中我们可以通过导入关键字模块查看当前系统中的Python关键字：



```bash
import keyword  # 导入关键字模块

# keyword.kwlist返回的是关键字列表
result = keyword.kwlist

print(result)
result_type = type(result)
print(result_type)

############## 输出结果 ###############

['False', 'None', 'True', 'and', 'as', 'assert', 'async', 'await', 'break', 'class', 'continue', 'def', 'del', 'elif', 'else', 'except', 'finally', 'for', 'from', 'global', 'if', 'import', 'in', 'is', 'lambda', 'nonlocal', 'not', 'or', 'pass', 'raise', 'return', 'try', 'while', 'with', 'yield']
<class 'list'>
```

## 4. 输出

`print("hello world")`就是最简单的输出
 通过print函数可以输出多个变量：



```bash
name = "张三"
age = 20

# 通过print函数可以输出多个变量
print(name, age)

############## 输出结果 ###############

张三 20
```

扩展：修改输出显示时的分隔符
 `sep`：表示指定多个数据输出时的分隔符：



```bash
name = "张三"
age = 20

# seq可以指定输出时的分隔符
print(name, age, sep="&")

# \n 表示换行符
print("你好\n世界")

############## 输出结果 ###############

张三&20
你好
世界
```

`end`：表示输出内容后面追加指定数据，默认追加的是`\n`：



```bash
name = "张三"
age = 20
job = "讲师"

# 没有指定end参数，默认后面是\n，所以打印完第一行之后再打印第二行会另起一行
print(name, age)
print(job)

# 指定end参数是 “ &”所以打印完第一行追加“ ！”后直接
print(name, age, end="&")
print(job)

############## 输出结果 ###############

张三 20
讲师
张三 20&讲师
```

`end`参数还可以指定为空格或者指定为空：



```bash
name = "李四"
address = "北京"
job = "讲师"

#end参数指定为空格
print(name, end= " ")
# 指定为空
print(job, end="")
print(address)

############## 输出结果 ###############

李四 讲师北京
```

### 格式化输出

> 格式化输出：将数据按照指定数据格式进行输出显示

- %d: 将数据以整型方式进行格式化输出
- %f: 将数据以浮点数方式进行格式化输出
- %s: 将数据以字符串方式进行格式化输出

文字描述太抽象，不好理解直接看代码：



```bash
age = 10
print("我今年%d岁" % age)
age += 1
print("我今年%d岁" % age)

############## 输出结果 ###############

我今年10岁
我今年11岁
```

上面代码告诉我们：**以后输出字符串的时候，字符串里面有动态内容，那么可以使用格式化方式进行输出。**

如果给多个格式化占位符传参，那么多个参数需要放到小括号：



```bash
name = "宋江"
age = 50

# 如果给多个格式化占位符传参，那么多个参数需要放到小括号
print("我叫:%s 年龄:%d" % (name, age))

############## 输出结果 ###############

我叫:宋江 年龄:50
```

- `name`是字符型所以要用`%s`占位符；
- `age`是`int`型所以要用`%d`占位符

字符型占位符 `%f` 默认保留六位小数，会进行四舍五入：



```bash
pi = 3.1415926

print("圆周率: %f" % pi)
print("圆周率: %.2f" % pi)

############## 输出结果 ###############

圆周率: 3.141593
圆周率: 3.14
```

`%f` 默认是保留六位小数，`%.2f`就是规定我只保留小数点后两位。

## 5. 输入— 接收用户输入的数据使用 `input()` 函数

平时的常规操作是，我们写代码然后运行，pycharm会给出相应的输出，其实也可以接受用户的输入，这时就需要 `input()` 函数：



```bash
password = input("请输入密码:")

############## 运行结果 ###############

请输入密码:
```

这时系统就会接受用户的输入



```bash
password = input("请输入密码:")  # 使用password这个变量保存用户输入数据
print("密码为:", password)

password_type = type(password)
print(password_type)

############## 运行结果 ###############

请输入密码:123
密码为: 123
<class 'str'>
```

总结：`input()` 接收用户的数据，返回的数据类型是字符串



```bash
name = input("请输入姓名:")
age = int(input("请输入年龄:"))
address = input("请输入地址:")

print("name: %s age: %d address: %s" % (name, age, address))

############## 运行结果 ###############

请输入姓名:宋江
请输入年龄:50
请输入地址:梁山
name: 宋江 age: 50 address: 梁山
```

前面说过`input()` 接收用户的数据，返回的是字符串，所以`age = int(input("请输入年龄:"))`一定记得要将`input()` 返回的字符串转成`int`型。因为`print()`后面的`age: %d`使用的是`int`型占位符`%d` ，如果上面不转换成`int`型就会报错说：
 `TypeError: %d format: a number is required, not str`
 当然如果上面不转换成`int`型，不报错还有一种解决办法就是`print()`后面的`age: %s`改成字符型占位符`%s`。

> 练习题：从键盘上录入苹果的价格 、重量 ，输出: 苹果单价 9.00 元／斤，购买了 5.00 ，需要⽀付 45.00 元.



```bash
price = float(input("苹果的单价为:"))
weight = float(input("购买的重量为:"))

result = price * weight
print("苹果单价 %.2f 元／⽄，购买了 %.2f ⽄，需要⽀付 %.2f 元." % (price, weight, result))

############## 运行结果 ###############

苹果的单价为:9
购买的重量为:5
苹果单价 9.00 元／⽄，购买了 5.00 ⽄，需要⽀付 45.00 元.
```

## 6. 运算符

python支持以下几种运算符：



![img]()

> 注意：混合运算时，优先级顺序为： `**` 高于 `* / % //` 高于 `+ -` ，为了避免歧义，建议使用 `()`来处理运算符优先级。
>  并且，不同类型的数字在进行混合运算时，整数将会转换成浮点数进行运算。

#### +   加



```bash
num1 = 5
num2 = 3

result = num1 + num2
print(result, type(result))

############## 运行结果 ###############

8 <class 'int'>
```

#### -   减



```bash
num1 = 5
num2 = 3

result = num1 - num2
print(result, type(result))

############## 运行结果 ###############

2 <class 'int'>
```

#### *   乘



```bash
num1 = 5
num2 = 3

result = num1 * num2
print(result, type(result))

############## 运行结果 ###############

15 <class 'int'>
```

#### /   除

注意：两个数字相除，返回的数据类是float



```bash
num1 = 5
num2 = 3

result = num1 / num2
print(result, type(result))

############## 运行结果 ###############

1.6666666666666667 <class 'float'>
```

#### //  取整除



```bash
num1 = 5
num2 = 3

result = num1 // num2
print(result, type(result))

############## 运行结果 ###############

1 <class 'int'>
```

#### %   求余数



```bash
num1 = 5
num2 = 3

result = num1 % num2
print(result, type(result))

############## 运行结果 ###############

2 <class 'int'>
```

#### ** 求几次方



```bash
num1 = 5
num2 = 3

result = num1 ** num2
print(result, type(result))

############## 运行结果 ###############

125 <class 'int'>
```

## 7. 赋值运算符

![img](https:////upload-images.jianshu.io/upload_images/15992481-65f627e591c057ff.png?imageMogr2/auto-orient/strip|imageView2/2/w/972/format/webp)

- 赋值运算符：=
- 赋值运算符：把等号右边的结果赋值给等号左边的变量，
- 注意：有等号先看等号右边的代码



```dart
num = 1 * 3 / 2 + 1
print(num, type(num))

############## 运行结果 ###############

2.5 <class 'float'>
```

**同时给多个变量赋值, 多个变量之间使用逗号进行分割**



```bash
name, age = "关胜", 40  # 拆包
print(name, age)

############## 运行结果 ###############

关胜 40
```

## 8. 复合赋值运算符

![img](https:////upload-images.jianshu.io/upload_images/15992481-f17b8ad5e2bb9164.png?imageMogr2/auto-orient/strip|imageView2/2/w/979/format/webp)

#### +=



```bash
num1 = 5
num1 += 3  # => num1 = num1 + 3

print(num1)

############## 运行结果 ###############

8
```

#### -=



```bash
num1 = 5
num1 -= 2  # => num1 = num1 - 2

print(num1)

############## 运行结果 ###############

3
```

#### *=



```bash
num1 = 5
num1 *= 3 # => num1 = num1 * 3

print(num1)

############## 运行结果 ###############

15
```

#### /=



```bash
num1 = 5
num1 /= 2  # => num1 = num1 / 2

print(num1)

############## 运行结果 ###############

2.5
```

#### **=



```bash
num1 = 5
num1 **= 2 # => num1 = num1 ** 2
print(num1)

############## 运行结果 ###############

25
```

#### //=



```bash
num1 = 5
num1 //= 4  # => num1 = num1 // 4
print(num1)

############## 运行结果 ###############

1
```

## 9. 数据类型

> 为什么要进行数据类型转换？
>  **类型统一才能完成相关的计算操作**

类型不统一进行计算操作会报错：



```bash
num1 = 1
my_str = "2"
result = num1 + my_str

print(result)

############## 运行结果 ###############

TypeError: unsupported operand type(s) for +: 'int' and 'str'
```

![img](Python基础—Day1.assets/15992481-09c92acfc71d24ab.png)

常用的数据类型转换

#### 把字符串转成`int`类型



```bash
num1 = 1
my_str = "2"

num2 = int(my_str)
print(num2, type(num2))

result = num1 + num2
print(result, type(result))

############## 运行结果 ###############

2 <class 'int'>
3 <class 'int'>
```

#### 把整型数字转成字符串类型



```bash
num1 = 1
my_str = "2"

my_str1 = str(num1)
print(my_str1, type(my_str1))

result = my_str + my_str1 #注意字符型相加和数字整型相加的区别
print(result, type(result))

############## 运行结果 ###############

1 <class 'str'>
21 <class 'str'>
```

#### 把字符串转成`float`类型



```bash
my_str3 = "3.14"
my_num = 5.16

my_float = float(my_str3)
result = my_float + my_num
print(result, type(result))

############## 运行结果 ###############

8.3 <class 'float'>
```

#### 把float类型转成字符串类型



```bash
my_str3 = "3.14"
my_num = 5.16
my_str4 = str(my_num)
print(my_str4, type(my_str4))
result = my_str3 + my_str4
print(result, type(result))

############## 运行结果 ###############

5.16 <class 'str'>
3.145.16 <class 'str'>
```

#### `eval：`获取字符串中的原始数据



```bash
my_str = "321"
result = eval(my_str)

print(result, type(result))

############## 运行结果 ###############

321 <class 'int'>
```

又举例：



```bash
abc = 1
my_str = "abc"
result = eval(my_str) # abc

print(result, type(result))

############## 运行结果 ###############

1 <class 'int'>
```

还举例：



```bash
my_str = "[1, 2]"
result = eval(my_str)
print(result, type(result))

############## 运行结果 ###############

[1, 2] <class 'list'>
```

#### `ord:`将一个字符转换为它的ASCII整数值

修改输出显示时的分隔符

```bash
my_char = "a"
result = ord(my_char)
print(result)

############## 运行结果 ###############

97
```

#### `chr：`将ASCII整数值转换为一个字符



```bash
result = chr(97)
print(result, type(result))

############## 运行结果 ###############

a <class 'str'>
```

> 这些都是黑马程序员Python基础课程的课堂笔记哦~



作者：黄晶_id
链接：https://www.jianshu.com/p/2ce9aa4a6a55
来源：简书
著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。